import unittest
import os
import json
import pandas as pd
from unittest.mock import patch
import tempfile
import logging
import sys
from io import StringIO
from main import SafeJSONLoader  # Ensure this import is correct

class TestSafeJSONLoader(unittest.TestCase):
    """Comprehensive unit tests for SafeJSONLoader class"""

    def setUp(self):
        """Initialize test data and suppress logs"""
        self.test_data = [
            {'id': 1, 'text': 'First sentence'},
            {'id': 2, 'text': 'Second sentence'},
            {'id': 3, 'text': 'Third sentence'}
        ]
        self.test_json = '\n'.join(json.dumps(item) for item in self.test_data)
        logging.disable(logging.CRITICAL)  # Suppress logging during tests

    def tearDown(self):
        """Restore logging"""
        logging.disable(logging.NOTSET)

    def test_load_normal_file(self):
        """Test normal JSON loading"""
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file.write(self.test_json)
            temp_file_path = temp_file.name

        try:
            loader = SafeJSONLoader()
            result = pd.concat(loader.load(temp_file_path))
            self.assertEqual(len(result), 3)
        finally:
            os.unlink(temp_file_path)

    def test_load_with_max_samples(self):
        """Test max_samples limit"""
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file.write(self.test_json)
            temp_file_path = temp_file.name

        try:
            loader = SafeJSONLoader(max_samples=2)
            result = pd.concat(loader.load(temp_file_path))
            self.assertEqual(len(result), 2)
        finally:
            os.unlink(temp_file_path)

    def test_load_with_chunking(self):
        """Test chunked loading"""
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file.write(self.test_json)
            temp_file_path = temp_file.name

        try:
            loader = SafeJSONLoader(chunk_size=1)
            chunks = list(loader.load(temp_file_path))
            self.assertEqual(len(chunks), 3)
        finally:
            os.unlink(temp_file_path)

    def test_load_empty_file(self):
        """Test empty file handling"""
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file_path = temp_file.name

        try:
            loader = SafeJSONLoader()
            result = list(loader.load(temp_file_path))
            self.assertEqual(len(result), 0)
        finally:
            os.unlink(temp_file_path)

    def test_load_malformed_json(self):
        """Test malformed JSON handling"""
        malformed_data = self.test_json + '\n{"id": 4, "text": "Bad" json}'

        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file.write(malformed_data)
            temp_file_path = temp_file.name

        try:
            loader = SafeJSONLoader()
            result = pd.concat(loader.load(temp_file_path))
            self.assertEqual(len(result), 3)
        finally:
            os.unlink(temp_file_path)

    def test_load_nonexistent_file(self):
        """Test non-existent file handling"""
        loader = SafeJSONLoader()
        with self.assertRaises(Exception):
            list(loader.load("nonexistent_file.json"))

    @patch('builtins.open', side_effect=Exception("Simulated IO error"))
    def test_load_io_error(self, mock_open):
        """Test IO error handling"""
        loader = SafeJSONLoader()
        with self.assertRaises(Exception):
            list(loader.load("any_file.json"))

    def test_unicode_handling(self):
        """Test Unicode character handling"""
        unicode_data = [{'id': 1, 'text': 'Café ☕'}]
        unicode_json = '\n'.join(json.dumps(item, ensure_ascii=False) for item in unicode_data)

        with tempfile.NamedTemporaryFile(mode='w+', encoding='utf-8', delete=False) as temp_file:
            temp_file.write(unicode_json)
            temp_file_path = temp_file.name

        try:
            loader = SafeJSONLoader()
            result = pd.concat(loader.load(temp_file_path))
            self.assertEqual(result.iloc[0]['text'], 'Café ☕')
        finally:
            os.unlink(temp_file_path)


def run_tests():
    """Run tests and save results"""
    suite = unittest.TestLoader().loadTestsFromTestCase(TestSafeJSONLoader)
    output_buffer = StringIO()
    runner = unittest.TextTestRunner(stream=output_buffer, verbosity=2)

    result = runner.run(suite)

    successful_tests = result.testsRun - (len(result.failures) + len(result.errors))  #  Calculate successful tests

    print("\nCaptured Test Output:\n", output_buffer.getvalue())

    print(f"\nSummary:\n"
          f"Tests run: {result.testsRun}\n"
          f"Successful: {successful_tests}\n"
          f"Failures: {len(result.failures)}\n"
          f"Errors: {len(result.errors)}")

    return result.wasSuccessful()



if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)
