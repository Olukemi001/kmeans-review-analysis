"""
Optimized K-Means Clustering with Complete Error Handling for
A collection of sentences extracted from customer reviews
labeled with their helpfulness score.
"""

#  Import libraries
import json  # For JSON file parsing
import logging  # For error and progress logging
from time import time  # For performance measurement
import warnings  # For warning suppression
import gc  # For memory management
import pandas as pd  # For data manipulation
import numpy as np  # For numerical operations
from sklearn.feature_extraction.text import TfidfVectorizer  # For text vectorization
from sklearn.cluster import MiniBatchKMeans  # For efficient clustering
from sklearn.decomposition import PCA  # For dimensionality reduction
import matplotlib.pyplot as plt  # For visualization
from tqdm import tqdm  # For progress bars

# Configuration to enhance warning, logging and plotting behaviour
warnings.filterwarnings('ignore')  # Suppress non-critical warnings
plt.ioff()  # Use non-interactive matplotlib mode to prevent hanging

# Logging setup - records both to file and console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("clustering.log"),  # Persistent log file
        logging.StreamHandler()  # Console output
    ]
)
logger = logging.getLogger(__name__)  # Create logger instance


class SafeJSONLoader:
    """Safely loads large JSON files in chunks to prevent memory issues"""

    def __init__(self, max_samples=None, chunk_size=5000):
        """
        Initialize loader with safety limits
        Args:
            max_samples: Maximum number of records to load
            chunk_size: Number of records to process at once
        """
        self.max_samples = max_samples
        self.chunk_size = chunk_size

    def load(self, filepath):
        """
        Load JSON file line by line with error handling
        Args:
            filepath: Path to JSON file
        Yields:
            DataFrames containing chunks of data
        Raises:
            Exception: If file cannot be read
        """
        data = []  # Buffer for current chunk
        count = 0  # Total records counter

        try:
            # Open file with explicit UTF-8 encoding
            with open(filepath, 'r', encoding='utf-8') as f:
                # Process each line with progress bar
                for line in tqdm(f, desc=f"Loading {filepath}"):
                    # Stop if max_samples reached
                    if self.max_samples and count >= self.max_samples:
                        break

                    try:
                        # Parse JSON line
                        data.append(json.loads(line))
                        count += 1

                        # Yield chunk when buffer is full
                        if len(data) >= self.chunk_size:
                            yield pd.DataFrame(data)
                            data = []  # Reset buffer
                            gc.collect()  # Free memory

                    except json.JSONDecodeError as e:
                        # Skip malformed lines but log warning
                        logger.warning(f"Skipping malformed line: {line[:100]}... Error: {str(e)}")
                        continue

                # Yield any remaining data
                if data:
                    yield pd.DataFrame(data)

        except Exception as e:
            logger.error(f"Fatal error loading {filepath}: {str(e)}")
            raise  # Re-raise for upstream handling


def preprocess_text(df, text_col='sentence'):
    """
    Clean and normalize text data with comprehensive error handling
    Args:
        df: Input DataFrame
        text_col: Name of text column to process
    Returns:
        DataFrame with added 'clean_text' column
    Raises:
        Exception: If preprocessing fails
    """
    logger.info("Starting text preprocessing...")
    start_time = time()

    try:
        # Text cleaning pipeline
        df['clean_text'] = (
            df[text_col]
            .str.lower()  # Convert to lowercase
            .str.replace(r'[^\w\s]', '', regex=True)  # Remove punctuation
            .str.replace(r'\s+', ' ', regex=True)  # Normalize whitespace
            .fillna('')  # Handle missing values
        )

        # Log completion
        duration = time() - start_time
        logger.info(f"Processed {len(df)} texts in {duration:.2f} seconds")
        return df

    except Exception as e:
        logger.error(f"Text preprocessing failed: {str(e)}")
        raise  # Re-raise for upstream handling


def vectorize_text(text_series, max_features=2000):
    """
    Convert text to numerical features with TF-IDF
    Args:
        text_series: Pandas Series of text documents
        max_features: Maximum number of vocabulary terms
    Returns:
        Tuple of (feature_matrix, vectorizer)
    Raises:
        Exception: If vectorization fails
    """
    logger.info("Starting text vectorization...")
    start_time = time()

    try:
        # Configure TF-IDF vectorizer
        vectorizer = TfidfVectorizer(
            max_features=max_features,  # Limit vocabulary size
            stop_words='english',  # Remove common words
            ngram_range=(1, 1),  # Use only unigrams
            min_df=5,  # Ignore rare terms
            max_df=0.95  # Ignore overly common terms
        )

        # Transform text to feature matrix
        feature_matrix = vectorizer.fit_transform(text_series)

        # Log completion
        duration = time() - start_time
        logger.info(
            f"Created {feature_matrix.shape[1]} features from {len(text_series)} "
            f"documents in {duration:.2f} seconds"
        )
        return feature_matrix, vectorizer

    except Exception as e:
        logger.error(f"Text vectorization failed: {str(e)}")
        raise


def optimized_elbow(X, max_k=2, sample_size=2000):
    """
    Determine optimal cluster count using elbow method with sampling
    Args:
        X: Feature matrix
        max_k: Maximum number of clusters to test
        sample_size: Number of samples to use for analysis
    Returns:
        List of within-cluster sum of squares values
    Raises:
        Exception: If clustering fails
    """
    logger.info("Starting elbow analysis...")

    try:
        # Sample data if larger than sample_size
        if X.shape[0] > sample_size:
            indices = np.random.choice(X.shape[0], sample_size, replace=False)
            X_sample = X[indices]
            logger.info(f"Using sample of {sample_size} from {X.shape[0]} points")
        else:
            X_sample = X

        wcss = []  # Within-cluster sum of squares
        for k in tqdm(range(1, max_k + 1), desc="Testing clusters"):
            try:
                # Fit MiniBatchKMeans for current k
                kmeans = MiniBatchKMeans(
                    n_clusters=k,
                    batch_size=1024,  # Process in batches
                    random_state=42,  # For reproducibility
                    n_init=3  # Number of initializations
                ).fit(X_sample)

                wcss.append(kmeans.inertia_)  # Store WCSS
                gc.collect()  # Free memory

            except Exception as e:
                logger.error(f"Failed clustering for k={k}: {str(e)}")
                raise

        # Generate elbow plot
        try:
            plt.figure(figsize=(8, 4))
            plt.plot(range(1, max_k + 1), wcss, 'bo-')
            plt.title(f'Elbow Method (n={sample_size})')
            plt.xlabel('Number of clusters')
            plt.ylabel('WCSS')
            plt.tight_layout()
            plt.savefig('elbow_plot.png', dpi=100, bbox_inches='tight')
            plt.close()
            logger.info("Saved elbow plot to elbow_plot.png")
        except Exception as e:
            logger.error(f"Failed to save elbow plot: {str(e)}")
            raise

        return wcss

    except Exception as e:
        logger.error(f"Elbow analysis failed: {str(e)}")
        raise


def safe_cluster_visualization(X, labels, sample_size=2000):
    """
    Generate cluster visualization safely for large datasets
    Args:
        X: Feature matrix
        labels: Cluster assignments
        sample_size: Number of points to visualize
    Raises:
        Exception: If visualization fails
    """
    logger.info("Preparing cluster visualization...")

    try:
        # Sample data if necessary
        if X.shape[0] > sample_size:
            indices = np.random.choice(X.shape[0], sample_size, replace=False)
            X_sample = X[indices]
            labels_sample = labels[indices]
            logger.info(f"Visualizing sample of {sample_size} from {X.shape[0]} points")
        else:
            X_sample = X
            labels_sample = labels

        # Reduce dimensionality with PCA
        try:
            pca = PCA(n_components=2, random_state=42)
            reduced = pca.fit_transform(X_sample.toarray())
        except Exception as e:
            logger.error(f"Dimensionality reduction failed: {str(e)}")
            raise

        # Create scatter plot
        try:
            plt.figure(figsize=(10, 6))
            plt.scatter(
                reduced[:, 0], reduced[:, 1],
                c=labels_sample,
                cmap='viridis',
                alpha=0.6,
                s=10  # Point size
            )
            plt.title(f'Cluster Visualization (n={sample_size})')
            plt.colorbar(label='Cluster')
            plt.tight_layout()
            plt.savefig('clusters.png', dpi=120, bbox_inches='tight')
            plt.close()
            logger.info("Saved cluster visualization to clusters.png")
        except Exception as e:
            logger.error(f"Plotting failed: {str(e)}")
            raise

    except Exception as e:
        logger.error(f"Cluster visualization failed: {str(e)}")
        raise


def main():
    """Main execution pipeline with comprehensive error handling"""
    try:
        # Configuration
        config = {
            'max_samples': None,  # Maximum records to load (None for all)
            'elbow_samples': 2000,  # Samples for elbow analysis
            'viz_samples': 2000,  # Samples for visualization
            'max_k': 2  # Maximum clusters to test
        }

        logger.info("Starting clustering pipeline...")

        # Data Loading
        logger.info("Loading data files...")
        try:
            loader = SafeJSONLoader(max_samples=config['max_samples'])
            train_df = pd.concat(loader.load("train.json"))
            test_df = pd.concat(loader.load("test.json"))
            df = pd.concat([train_df, test_df])
            logger.info(f"Successfully loaded {len(df)} total records")
        except Exception as e:
            logger.error("Data loading failed - check file paths and formats")
            raise

        # Text Preprocessing
        try:
            df = preprocess_text(df)
        except Exception as e:
            logger.error("Text preprocessing failed")
            raise

        # Feature Vectorization
        try:
            X, vectorizer = vectorize_text(df['clean_text'])
        except Exception as e:
            logger.error("Text vectorization failed")
            raise

        # Cluster Analysis
        try:
            wcss = optimized_elbow(
                X,
                max_k=config['max_k'],
                sample_size=config['elbow_samples']
            )
            # Auto-select optimal k (first point where improvement <10%)
            optimal_k = np.argmin(np.diff(wcss) / wcss[:-1] > 0.1) + 2
            logger.info(f"Determined optimal clusters: k={optimal_k}")
        except Exception as e:
            logger.error("Cluster analysis failed")
            raise

        # Final Clustering
        try:
            logger.info(f"Running final clustering with k={optimal_k}...")
            kmeans = MiniBatchKMeans(
                n_clusters=optimal_k,
                batch_size=1024,
                random_state=42,
                n_init=3
            )
            clusters = kmeans.fit_predict(X)
        except Exception as e:
            logger.error("Final clustering failed")
            raise

        # Visualization
        try:
            safe_cluster_visualization(
                X, clusters,
                sample_size=config['viz_samples']
            )
        except Exception as e:
            logger.error("Visualization failed (continuing without plots)")
            # Continue even if visualization fails

        # Save Results
        try:
            df['cluster'] = clusters
            df.to_csv("clustered_results.csv", index=False)
            logger.info("Successfully saved results to clustered_results.csv")
        except Exception as e:
            logger.error("Failed to save results")
            raise

        logger.info("Pipeline completed successfully")

    except Exception as e:
        logger.critical(f"Pipeline failed: {str(e)}")
        raise  # Re-raise to exit program


if __name__ == "__main__":
    """Entry point with top-level error handling"""
    try:
        main()
    except Exception as e:
        logger.critical(f"Fatal error: {str(e)}")
        exit(1)  # Exit with error code